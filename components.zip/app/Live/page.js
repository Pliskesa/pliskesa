export default function Live() {
  return (
    <div>
      <h1>Live Matches</h1>
      <p>Statistiques en direct bientôt disponibles...</p>
    </div>
  );
}
