export default function Bets() {
  return (
    <div>
      <h1>Bets</h1>
      <p>Liste des paris disponibles.</p>
    </div>
  );
}
