export default function Stats() {
  return (
    <div>
      <h1>Statistiques</h1>
      <p>Données statistiques du site.</p>
    </div>
  );
}
