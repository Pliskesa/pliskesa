export default function Admin() {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p>Gestion du site Pliskesa.</p>
    </div>
  );
}
