export default function Header() {
  return (
    <header style={{
      background: "#00b5ad",
      padding: "15px",
      color: "white",
      fontSize: "20px",
      fontWeight: "bold"
    }}>
      Pliskesa
    </header>
  );
}
