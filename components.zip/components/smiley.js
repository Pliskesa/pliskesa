export default function Smiley({ win }) {
  return (
    <span style={{ fontSize: "40px" }}>
      {win ? "😄" : "😢"}
    </span>
  );
}
